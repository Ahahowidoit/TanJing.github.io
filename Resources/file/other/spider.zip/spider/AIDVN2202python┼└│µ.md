

# Python数据采集

```
讲师: 魏明择
时间: 2022年
```

[TOC]



## day01笔记

### 1. 网络爬虫概述

**什么是爬虫**

1. 爬虫就是用Python程序模仿人点击浏览器并访问网站，获取互联网上数据的一种方式。
2. 爬虫又名网络蜘蛛、网络机器人，是抓取网络数据的程序

> 模仿的越逼真不容易被网站发现

**爬取数据的目的**

1. 从互联网获取大量数据，用来做数据分析，提高公司的业务水平。
2. 公司项目的测试数据，公司业务所需数据。

**企业获取数据方式**

1. 公司自有数据
2. 第三方数据平台购买(数据堂、贵阳大数据交易所)
3. 爬虫爬取数据

**Python做爬虫优势**

1. Python ：请求模块、解析模块丰富成熟,强大的Scrapy网络爬虫框架
2. JAVA：代码笨重,代码量大
3. C/C++：虽然效率高,但是代码成型慢
4. PHP ：对多线程、异步支持不太好



**爬虫分类**

1. 通用网络爬虫(搜索引擎使用,遵守robots协议)
   robots协议: 网站通过robots协议告诉搜索引擎哪些页面可以抓取,哪些页面不能抓取，通用网络爬虫需要遵守robots协议（君子协议）
   示例: https://www.taobao.com/robots.txt
2. 聚焦网络爬虫 ：自己写的爬虫程序





**爬取数据步骤**

1. 确定需要爬取的URL地址
2. 由请求模块向URL地址发出请求,并得到网站的响应
3. 从响应内容中提取所需数据
      1）所需数据,保存
      2）页面中有其他需要继续跟进的URL地址,继续第2步去发请求，如此循环

### 2. requests模块

- 作用

  模拟浏览器向网站发送GET、POST、HEAD等请求并得到响应

  > requests 模块是第三方模块，需要安装后才能使用

- 官方文档 

  https://docs.python-requests.org/en/master/

- **安装**

  在Linux 下安装 requests 模块

  ```shell
  ip3 install requests
  ```

  在 Windows 下安装 requests 模块

  ```python
  # 方法1:  cmd命令行 ->
  python -m pip install requests
  # 方法2:  右键管理员进入cmd命令行 ：
  pip install requests
  ```

#### 1) requests的 GET请求

- 函数参数

```python
resp = requests.get(
    url,  # 请求地址（需要爬取的URL地址）
    params={},  # 查询参数
    headers={},  # 请求头信息
    cookies={},  # 携带COOKIES
    auth=(),  # 用户验证信息
    proxies={},  # 代理服务的字典
    verify=True,   # 检查证书认证(默认为True) 
    timeout=None,  # 相应的超时时间（浮点数）超过时间会抛出异常
)
```

- 作用

  向目标网站发起GET请求,并获取响应对象

- 返回值:

  requests.Respose对象

- 响应对象( requests.Respose )的属性

```python
1、resp.encoding ：响应字符编码(可以通过赋值语句来更换编码)
   resp.encoding = 'utf-8'
2、resp.content ：返回的字节串
3、resp.text ：根据resp.encoding 解码后的字符串
4、resp.status_code ：HTTP响应码
5、resp.url ：实际数据的URL地址
```

示例

```python
import requests

resp = requests.get('https://www.baidu.com')
print(resp.encoding)  # 查看默认的编码
print(resp.status_code)  # 查看http状态码
print(resp.url)  # 查看链接
print(resp.text)  # 查看 返回内容
resp.encoding='utf8'  # 将编码转换为utf8
print(resp.text)  # 查看 返回内容
```

### 3. 第一个爬虫程序

- 问题

```
# 打开浏览器，输入百度网址(http://www.baidu.com/)，得到百度的响应内容
# 用程序将 http://www.baidu.com 主页中的内容打印到控制台终端.
```

示例代码

```python
# 用程序将 http://www.baidu.com 主页中的内容打印到控制台终端.
import requests

url = 'http://www.baidu.com/'
resp = requests.get(url)
html = resp.content.decode('utf-8')
print(html)
```

### 4. 用户代理User-Agent

**什么是用户代理User-Agent**

User Agent中文名为用户代理，简称 UA，**它是浏览器用户标识自己的类型及操作系统类型的一个特殊字符串**。

此字符串将发送给服务器端，使得服务器能够识别客户使用的操作系统及版本、CPU 类型、浏览器及版本、浏览器渲染引擎、浏览器语言、浏览器插件等。

 **一个用于测试HTTP传输内容的网站**

- 网址:

  http://httpbin.org/get

  **响应内容示例**

  ```json
  {
    "args": {}, 
    "headers": {
      "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9", 
      "Accept-Encoding": "gzip, deflate", 
      "Accept-Language": "zh-CN,zh;q=0.9", 
      "Host": "httpbin.org", 
      "Upgrade-Insecure-Requests": "1", 
      "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.116 Safari/537.36", 
      "X-Amzn-Trace-Id": "Root=1-61bd4102-775abe2224e8d1297e7879aa"
    }, 
    "origin": "223.72.184.220", 
    "url": "http://httpbin.org/get"
  }
  ```

  

- **使用request模块来获取响应内容**

  ```python
  import requests
  
  
  url = 'http://www.httpbin.org/get'
  # 1. 根据url获取响应对象
  resp = requests.get(url)
  # 2. 将响应对象的内容解码为html
  html = resp.content.decode('utf-8')
  print(html)
  ```

**如何在Chrome浏览器当中去查找用户代理**

```
1. 打开Chrome浏览器
2. 输入任何一个可以浏览的网页（如: https://www.baidu.com)
3. 在页面上右键单击鼠标选择"检查"(或者按下F12快捷键)进入开发者工具界面
4. 点击"Network" 标签页
5. 刷新当前的网页
6. 查看name 第一个请求的数据包,并单击选中
7. 查看右侧的headers标签页, 找到下方的"Request Headers" 在最下面
8. 复制 User-Agent选项和他的值
如:Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.80 Safari/537.36
```

如下图所示

![](images/chrome_useragent.png)



**如何在请求中添加用户代理?**

requests模块中提供了get和post函数中给出了**headers**关键字参数，可以在发送请求时携带自定义的请求头。包括User-Agent。

**requests.get()函数和request.post()函数 中的headers关键字参数**

- requests.get/post函数

```python
requests.get(url, headers={})
# 或者
requests.post(url, headers={}, data={})
```

> 参数:
> 1）url：请求的URL地址
> 2）headers：请求头字典，其中的键值对内容会加入到请求头中。
> 3)  data: 在POST请求中用来添加数据（很少使用)

- 作用
  创建请求头对象(包装请求头，重构User-Agent、Cookies等信息，使程序更像浏览器的请求)

- **示例（没有请求头）**

```python
import requests

url = 'http://www.httpbin.org/get'
# 1. 根据url获取响应对象
resp = requests.get(url)
# 2. 将响应对象的内容解码为html
html = resp.content.decode('utf-8')
print(html)
```

- **示例(添加请求头)**

  重构User-Agent向测试网站发请求并确认（http://httpbin.org/get）

```python
# 1. 导入 requests模块
import requests

# 2. 定义 url
url = 'http://www.httpbin.org/get'
# 3. 构造请求对象(重构User-Agent)
headers = {
    'User-Agent': 'Mozilla/5.0'
}
# 4. 根据url和headers 获取响应对象
resp = requests.get(url, headers=headers)
# 5. 将响应对象的内容解码为html
html = resp.content.decode('utf-8')
# 6. 打印html
print(html)
```



- **小总结**

```python
# 1.请求模块
requests 
【1】resp = requests.get(url, headers=headers)
【2】html = resp.content.decode()

# 2.编码模块
urllib.parse
url = 'http://www.baidu.com/s?{}'
【1】urllib.parse.urlencode({'wd':'xxx','pn':'yyy'})

url = 'http://www.baidu.com/s?wd={}&pn={}'
【2】urllib.parse.quote('xxx')
```

- 爬虫程序的基本步骤

  1. 确认爬取的目标 的url 地址
  2. 生成相应的URL地址
  3. 获取HTML(或 JSON的内容）
  4. 解析文档的内容
  5. 持久化存储数据内容

- 爬虫程序的基本结构

```python
# 程序结构
class xxxSpider:
    def __init__(self):
        '''定义常用变量,url格式,headers等'''

    def get_html(self, url):
        '''根据给定的url获取响应内容并返回html'''

    def parse_html(self, html):
        '''使用正则表达式或者xpath来解析页面，提取数据'''

    def save_data(self, item):
        '''将提取的数据item按要求保存到csv、MySQL数据库中'''

    def run(self):
        '''主函数，用来控制整体逻辑'''

if __name__ == '__main__':
    spider = xxxSpider()
    spider.run()
```







### 5. HTML数据解析

Html 数据解析是将由各种格式标签和文本数据组成的HTML 文本信息中的数据分离出来，供使用。

**常用的数据解析技术**

1. 正则表达式
2. xpath解析式 
3. JSON解析

### **6. 正则解析模块re**

**re模块使用流程**

```python

r_list=re.findall('正则表达式',html,re.S)

```

#### **1) 正则表达式元字符**

| 元字符 | 含义                              |
| ------ | --------------------------------- |
| .      | 任意一个字符（不包括\n）          |
| \d     | 一个数字                          |
| \w     | 一个字符                          |
| \s     | 空白字符(`'\t', '\n', '\r', ' '`) |
| \S     | 非空白字符                        |
| []     | 包含[]内容                        |
| *      | 出现0次或多次                     |
| +      | 出现1次或多次                     |

- **思考 - 请写出匹配任意一个字符的正则表达式？**

```python
import re
# 方法一
pattern = re.compile('[\s\S]')
result = pattern.findall(html)
# 方法二
pattern = re.compile('.', re.S)
result = pattern.findall(html)
```

> 参数 `re.S` 是让 元字符 `.` 能够匹配 `'\n'` 这个换行符

#### **2) 贪婪匹配和非贪婪匹配**

- **贪婪匹配(默认)**

  ```python
  1、在整个表达式匹配成功的前提下,尽可能多的匹配 * + ?
  2、表示方式：.* .+ .?
  ```

- **非贪婪匹配**

  ```python
  1、在整个表达式匹配成 功的前提下,尽可能少的匹配 * + ?
  2、表示方式：.*? .+? .??
  ```

- **代码示例**

  ```python
  import re
  
  html = '''
  <div><p>锄禾日当午，</p></div>
  <div><p>汗滴禾下土。</p></div>
  '''
  # 贪婪匹配
  p = re.compile('<div><p>.*</p></div>',re.S)
  r_list = p.findall(html)
  print(r_list)
  
  # 非贪婪匹配
  p = re.compile('<div><p>.*?</p></div>',re.S)
  r_list = p.findall(html)
  print(r_list)
  ```

#### **3) 正则表达式分组**

- **作用**

  在完整的模式中定义子模式，将每个圆括号`()`中子模式匹配出来的结果提取出来
  
- **示例代码**

  ```python
  import re
  
  s = 'A B C D'
  p1 = re.compile('\w+\s+\w+')
  print(p1.findall(s))
  # 分析结果是什么？？？
  # ['A B','C D']
  p2 = re.compile('(\w+)\s+\w+')
  print(p2.findall(s))
  # 第1步: ['A B','C D']
  # 第2步: ['A','C']
  
  p3 = re.compile('(\w+)\s+(\w+)')
  print(p3.findall(s))
  # 第1步: ['A B','C D']
  # 第2步: [('A','B'),('C','D')]
  ```

- **补充 - 更改文件编码**

  ```python
  windows中 右键文件 - 打开方式 - 记事本 - 文件 - 另存为 - 编码(选择所需编码) - 保存
  ```
  
- **分组总结**

  ```python
  1、在网页中,想要什么内容,就加()
  2、先按整体正则匹配,然后再提取分组()中的内容
     如果有2个及以上分组(),则结果中以元组形式显示 [(),(),()]
  ```

- **课堂练习**

  ```python
  # 从如下html代码结构中完成如下内容信息的提取：
  问题1 ：[('Tiger',' Two...'),('Rabbit','Small..')]
  问题2 ：
  	动物名称 ：Tiger
  	动物描述 ：Two tigers two tigers run fast
      **********************************************
  	动物名称 ：Rabbit
  	动物描述 ：Small white rabbit white and white
  ```

- **页面结构如下**

  ```html
  <div class="animal">
      <p class="name">
  		<a title="Tiger"></a>
      </p>
      <p class="content">
  		Two tigers two tigers run fast
      </p>
  </div>
  
  <div class="animal">
      <p class="name">
  		<a title="Rabbit"></a>
      </p>
      <p class="content">
  		Small white rabbit white and white
      </p>
  </div>
  ```

- **练习答案**

  ```python
  import re
  
  html = '''<div class="animal">
      <p class="name">
          <a title="Tiger"></a>
      </p>
  
      <p class="content">
          Two tigers two tigers run fast
      </p>
  </div>
  
  <div class="animal">
      <p class="name">
          <a title="Rabbit"></a>
      </p>
  
      <p class="content">
          Small white rabbit white and white
      </p>
  </div>'''
  
  p = re.compile('<div class="animal">.*?title="(.*?)".*?content">(.*?)</p>.*?</div>',re.S)
  r_list = p.findall(html)
  
  for rt in r_list:
      print('动物名称:',rt[0].strip())
      print('动物描述:',rt[1].strip())
      print('*' * 50)
  ```





### 7. 豆瓣电影top250抓取案例

- **爬虫需求**

  ```python
  # 1. 网址: 
      https://movie.douban.com/
  # 2. 位置:
      豆瓣电影 --> 排行榜 --> 豆瓣电影TOP250 全部（右下部分）
  # 3. 确定链接: 
      https://movie.douban.com/top250
  # 4. 爬取目标
      电影名称、评分、评价人数
  ```

- **爬虫实现**

  ```python
  # 1. 查看网页源码，确认数据来源
  响应内容中存在所需抓取数据 - 电影名称、评分、评价人数
  
  # 2. 翻页寻找URL地址规律
  第1页：https://movie.douban.com/top250?start=0
  第2页：https://movie.douban.com/top250?start=25
  第n页：start=(page-1)*25
  
  # 3. 编写正则表达式
      r'<span class="title">(.*?)</span>.*?property="v:average">(.*?)</span>.*?<span>(.*?)人评价</span>'
  ```

- **代码实现**

  ```python
  # file: douban_movie_top250_spider.py
  # 目标，爬取豆瓣电影排行榜 Top250 的250条数据
  
  import re
  import time
  import requests
  
  
  class DoubanTop250Spider:
      def __init__(self):
          '''定义常用的变量，如url格式, headers等信息'''
          self.url_fmt = 'https://movie.douban.com/top250?start={}'
  
      def get_html(self, url):
          '''通过给定的url, 获取对应网页的html,并返回'''
          headers = {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
          }
          resp = requests.get(url, headers=headers)
          html = resp.content.decode()
          return html
  
      def parse_html(self, html):
          '''使用这则表达式，解析html中的数据,准备存储'''
          pattern = r'''<div class="hd">.*?<span class="title">(.*?)</span>.*?property="v:average">(.*?)</span>.*?<span>(.*?)人评价</span>'''
          li_list = re.findall(pattern, html, re.S)
          print(li_list)  # [(), (), (), ...]
          for title, rating, count in li_list:
              item = (title, rating, count)
              self.save_data(item)
  
      def save_data(self, item):
          'item是一个电影的信息, 此方法用来持久化保存item'
          print(item)
  
      def run(self):
          '主函数，用来控制爬取的流程'
          # 循环生成url 链接地址，准备爬取信息
          for page in range(1, 11):
              start = (page - 1) * 25
              url = self.url_fmt.format(start)
              print('正在爬取:', url)
              # 1. 根据url 得到html
              html = self.get_html(url)
              # 2. 将html 保存成为文件
              # filename = '豆瓣电影Top250_第{}页.html'.format(page)
              # with open(filename, 'w') as fw:
              #     fw.write(html)
              # 3. 解析html 提取数据并存储
              self.parse_html(html)
              # 4. 增加延时(模拟手动操作)
              time.sleep(5)
  
  
  if __name__ == '__main__':
      spider = DoubanTop250Spider()
      spider.run()  # 开始爬取数据
  ```





### 8. 课后练习

```
【1】正则抓取豆瓣图书top250书籍信息
	地址：https://book.douban.com/top250?icn=index-book250-all
    抓取目标：书籍名称、书籍信息、书籍评分、书籍评论人数、书籍描述
    
```







### 9. 数据持久化

数据持久化就是将内存中的数据存储为以某种数据结构的可永久保存和读取的数据。

持久化的数据结构可以是。XML结构、二进制流、关系型数据库表，CSV数据文件等。

经过爬虫获取来的数据，通常我们要永久存储供后续数据分析使用。

**常用的数据持久化的方法有:**

1. CSV 文件存储

2. SQL数据库文件存储

3. Xlsx 文件存储

4. MongoDB存储


我们将计算机内存中的数据存储到计算机的外部。外部存储结构当中。

**为降低数据持久化的代码和爬虫程序的耦合度，可以使用面向对象的方法对持久化对象进行封装，实现高内聚低耦合**

我们将数据持久化对象称之为存储器对象(Saver)，存储器对象可以采用如下方式定义。

```python
class XxxxSaver:
    def __init__(self):
        '''在此初始化方法当中可以进行打开数据库、打开文件等操作。'''

    def save_item(self, item):
        '''接口方法，把item序列化到数据库或文件中，item可以是元组或字典'''

    def __del__(self):
        '''
        此析构方法，会在对象销毁的时候自动调用。
        我们可以在此方法内进行关闭数据库、关闭文件等操作。
        '''
```

#### 1）数据持久化 - csv文件存储

- 作用

  将爬取的数据存放到本地的csv文件中

- 使用流程

  1、导入模块
  2、打开csv文件
  3、初始化写入对象
  4、写入数据(参数为列表)

- 示例

```python
# 创建 mydata.csv 文件，在文件中写入数据
# 单行写入：.writerow([])
import csv 
with open('mydata.csv','w') as fw:
    writer = csv.writer(fw)
    writer.writerow(['name', 'age'])
    writer.writerow(['小张', 18]) 
```

> 单行写入：.writerow([])

- **示例代码**

```python
# 创建 test.csv 文件，在文件中写入数据
# 多行写入(writerows([(),(),()]
import csv
with open('test.csv','w') as f:
	writer = csv.writer(f)
	writer.writerows([('聂风','36'),('秦霜','25'),('孔慈','30')])
```

- 持久化到CSV文件的类声明

> file: douban_csv_saver.py

```python
# file: douban_csv_saver.py

import csv

class DoubanCsvSaver:
    def __init__(self, filename='temp.csv'):
        '打开csv文件，准备存储'
        self.f_write = open(
            filename, 'w', encoding='gb18030'
        )
        self.csv_writer = csv.writer(self.f_write)
        self.csv_writer.writerow(
            ['片名', '评分', '评分人数']
        )

    def save_item(self, item):
        '接口方法，把item序列化到csv文件中'
        self.csv_writer.writerow(item)

    def __del__(self):
        '''析构方法，此方法会在对象销毁后调用
        次方法用于关闭文件
        '''
        self.f_write.close()
        print('csv文件已经正常关闭')

if __name__ == '__main__':
    saver = DoubanCsvSaver()
    saver.save_item(
        ['Tom & Jerry', 9.5, '21003']
    )
```

- 爬虫程序接口代码:

```python
class DoubanTop250Spider:
    def __init__(self, saver=None):
        # 将saver 用self.saver绑定，供后续使用
        self.saver = saver

    def get_html(self, url):
        '''通过给定的url, 获取对应网页的html,并返回'''
        pass

    def parse_html(self, html):
        '''使用这则表达式，解析html中的数据,准备存储'''
        pass

    def save_data(self, item):
        'item是一个电影的信息, 此方法用来持久化保存item'
        print(item)
        if self.saver:
            self.saver.save_item(item)

    def run(self):
        '主函数，用来控制爬取的流程'
        pass

if __name__ == '__main__':
    from douban_csv_saver import DoubanCsvSaver
    saver = DoubanCsvSaver('douban_top250.csv')
    spider = DoubanTop250Spider(saver)
    spider.run()  # 开始爬取数据
```



### 10. xpath解析

- **定义**

  XPath即为XML路径语言，它是一种用来确定XML文档中某部分位置的语言，同样适用于HTML文档的检索

#### 2.1 xpath的语法

- **示例HTML代码**

  > File: xpath_demo.html

  ```python
  <!doctype html>
  <html lang="en">
  <head>
      <meta charset="UTF-8">
      <title>XPath示例</title>
  </head>
  <body>
      <ul class="CarList">
          <li class="bjd" id="car_001">
              <p class="name">
                  <a href="http://www.bjd.com/">布加迪</a>
              </p>
              <p class="model">威航</p>
              <p class="price">2500万</p>
              <p class="color">红色</p>
          </li>
  
          <li class="byd" id="car_002">
              <p class="name">
                  <a href="http://www.byd.com/">比亚迪</a>
              </p>
              <p class="model">秦</p>
              <p class="price">15万</p>
              <p class="color">白色</p>
          </li>
      </ul>
  </body>
  </html>
  ```

- XPath选取节点的方法

  XPath 使用路径表达式在 XML 文档中选取节点。节点是通过沿着路径或者 step 来选取的。

  路径表达式：

  |  表达式  | 描述                                                       |
  | :------: | :--------------------------------------------------------- |
  | nodename | 选取此节点的所有子节点。                                   |
  |    /     | 从根节点选取。                                             |
  |    //    | 从匹配选择的当前节点选择文档中的节点，而不考虑它们的位置。 |
  |    .     | 选取当前节点。                                             |
  |    ..    | 选取当前节点的父节点。                                     |
  |    @     | 选取属性。                                                 |

- **选取节点元素**

  使用 节点标签名 可以选择节点，返回节点元素的列表
  
  示例
  
  ```
  # 1. 查找 根下html/body下的所有的 div 元素
  /html/body/div
  # 2. 查找 任意节点下的ul下的所有的 li 元素
  //ul/li
  ```
  
  

- **谓语选择（Predicates）**

  谓语用来查找某个特定的节点或者包含某个指定的值的节点。
  
  谓语被嵌在方括号中
  
  示例
  
  ```
  # 1. 查找 p 元素（其中要求必须有类名为name) 如<p class="name">
  //p[@class="name"]
  # 2. 查找 li标签下的第二个p元素
  //li/p[2]
  # 3. 查找 li 标签下最后一个p元素
  //li/p[last()]
  # 4. 查找 li 标签下前两个 p元素
  //li/p[position()<3]
  # 5. 查找 li 标签下其中 id 属性的值中包含 "car_" 的 li 节点元素
  #     contains() ：匹配属性值中包含某些字符串节点
  //li[contains(@id,"car_")]
  ```
  

#### 2.2 lxml解析库

- **安装**

  ```python
  sudo pip3 install lxml
  ```

- **使用流程**

  ```python
  1、导模块
     from lxml import etree
  2、创建解析对象
     tree = etree.HTML(html)
  3、解析对象调用xpath
     r_list = tree.xpath('xpath表达式')
  ```

- **常用函数**

  ```python
  text() ：获取节点的文本内容
  # 查找所有汽车的价格
  //ul[@class="CarList"]/li/p[@class="price"]/text() 
  ```
  
- xpath返回两种类型的对象列表

  ```
  1、节点对象列表
     # xpath示例: //div、//div[@class="student"]、//div/a[@title="stu"]/span
  2、字符串列表
     # xpath表达式中末尾为: @src、@href、text()
  ```

  > 节点对象可以再次使用xpath方法 进行取值





- **匹配演示**

  ```python
  # file: xpath_demo.py
  from lxml import etree
  
  with open('xpath_demo.html') as fr:
      html = fr.read()
  
  tree = etree.HTML(html)
  print(tree)
  
  # 1、查找所有的li节点
  #    //li
  print(tree.xpath('//li'))
  # 2、获取所有汽车的名称: 所有li节点下的子节点p的值 (class属性值为name）
  #    //li/p[@class="name"]
  print(tree.xpath('//li/p[@class="name"]'))
  # 3、获取ul节点下第2个li节点的汽车信息: 找比亚迪车的信息
  #    //ul[@class="CarList"]/li[2]/p
  print(tree.xpath('//ul[@class="CarList"]/li[2]/p'))
  # 4、获取所有汽车的链接: ul节点下所有li子节点下p节点下a节点的href属性的值
  #    //ul/li/p/a/@href
  print(tree.xpath('//ul/li/p/a/@href'))
  # 5、含有类"CarList"的 ul 节点下的li阶段的id的属性值
  #    //ul[@class="CarList"]/li/@id
  print(tree.xpath('//ul[@class="CarList"]/li/@id'))
  
  print(tree.xpath('//ul/li/p[3]/text()'))
  
  
  ```
  
  > 只要涉及到条件,加 []
  >
  > 只要获取属性值,加 @
  

### 11. 豆瓣电影Top250案例-xpath

```python
# file: douban_movie_top100_spider_xpath.py
# 目标，爬取豆瓣电影排行榜 Top250 的250条数据

import time
import requests

from lxml import etree

class DoubanTop250Spider:
    def __init__(self):
        '''定义常用的变量，如url格式, headers等信息'''
        self.url_fmt = 'https://movie.douban.com/top250?start={}'

    def get_html(self, url):
        '''通过给定的url, 获取对应网页的html,并返回'''
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
        }
        resp = requests.get(url, headers=headers)
        html = resp.content.decode()
        return html

    def parse_html(self, html):
        '''使用XPath表达式，解析html中的数据'''
        tree = etree.HTML(html)

        li_list = tree.xpath('//ol[@class="grid_view"]/li')
        # print(li_list)
        for li in li_list:
            title = li.xpath('.//div[@class="info"]/div/a/span[@class="title"]/text()')[0]
            rating = li.xpath('.//div[@class="info"]/div/div/span[@property="v:average"]/text()')[0]
            count = li.xpath('.//div[@class="info"]/div/div/span[last()]/text()')[0].rstrip('人评价')
            item = (title, rating, count)
            self.save_data(item)

    def save_data(self, item):
        'item是一个电影的信息, 此方法用来持久化保存item'
        print(item)

    def run(self):
        '主函数，用来控制爬取的流程'
        # 循环生成url 链接地址，准备爬取信息
        for page in range(1, 11):
        # for page in range(1, 2):
            start = (page - 1) * 25
            url = self.url_fmt.format(start)
            print('正在爬取:', url)
            # 1. 根据url 得到html
            html = self.get_html(url)
            # 2. 将html 保存成为文件
            # filename = '豆瓣电影Top250_第{}页.html'.format(page)
            # with open(filename, 'w') as fw:
            #     fw.write(html)
            # 3. 解析html 提取数据并存储
            self.parse_html(html)
            # 4. 增加延时(模拟手动操作)
            time.sleep(5)


if __name__ == '__main__':
    spider = DoubanTop250Spider()
    spider.run()  # 开始爬取数据
```





### 12. 使用代理服务器

**requests.get() 方法的代理参数-proxies**

- **定义及分类**

  ```python
  # 1. 定义
  代替你原来的IP地址去对接网络的IP地址
  
  # 2. 作用
  隐藏自身真实IP,避免被封
  
  # 3. 种类
  1) 高匿代理: Web服务器端只能看到代理IP
  2) 普通代理: Web服务器端知道有人通过此代理IP访问，但不知用户真实IP
  3) 透明代理: Web服务器端能看到用户真实IP，也能看到代理IP
  ```

  **获取代理**

  ```
  # 1. 获取代理IP网站
  快代理: https://www.kuaidaili.com/
  流冠代理 : https://www.hailiangip.com/
  精灵代理: https://www.jinglingip.com/
  ... ...
  ```

  

- **普通代理**

  ```python
  # 1. 语法结构
  proxies = { '协议':'协议://IP:端口号' }
  
  # 2. 示例
  proxies = {
      	'http':'http://IP:端口号',
      	'https':'https://IP:端口号',
  }
  ```

- **普通代理 - 示例**

  ```python
  # 使用免费普通代理IP访问测试网站: http://httpbin.org/get
  import requests
  
  url = 'http://httpbin.org/get'
  headers = {
      'User-Agent':'Mozilla/5.0'
  }
  # 定义代理,在代理IP网站中查找免费代理IP
  proxies = {
      'http':'http://112.85.164.220:9999',
      'https':'https://112.85.164.220:9999'
  }
  html = requests.get(url,proxies=proxies,headers=headers,timeout=5).text
  print(html)
  ```

- **私密代理+独享代理**

  ```python
  # 1. 语法结构
  proxies = { '协议':'协议://用户名:密码@IP:端口号' }
  
  # 2. 示例
  proxies = {
  	'http':'http://用户名:密码@IP:端口号',
      'https':'https://用户名:密码@IP:端口号',
  }
  ```

- **私密代理+独享代理 - 示例代码**

  ```python
  import requests
  url = 'http://httpbin.org/get'
  proxies = {
      'http': 'http://weimz:7xrocci7@106.75.71.140:16816',
      'https':'https://weimz:7xrocci7@106.75.71.140:16816',
  }
  headers = {
      'User-Agent' : 'Mozilla/5.0',
  }
  
  html = requests.get(url,proxies=proxies,headers=headers,timeout=5).text
  print(html)
  ```



- **普通代理 - 建立代理IP池**

  思考: 建立一个自己的代理IP池 - 抓取快代理网站代理IP并测试是否可用

  File: 

  ```python
  # 思考: 建立一个自己的代理IP池 - 抓取快代理网站代理IP并测试是否可用
  
  import time
  
  import requests
  from lxml import etree
  
  
  class GetProxyIP(object):
      def __init__(self, saver=None):
          self.saver = saver
          self.url_fmt = 'https://www.kuaidaili.com/free/inha/{}/'
          self.headers = {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36',
          }
  
      def get_html(self, url):
          resp = requests.get(url=url, headers=self.headers, timeout=5)
          html = resp.content.decode()
          return html
  
      def parse_html(self, html):
          '''解析html里面的内容'''
          tree = etree.HTML(html)
          tr_list = tree.xpath('//tbody/tr')
          for tr in tr_list:
              ip = tr.xpath('./td[1]/text()')[0]
              port = tr.xpath('./td[2]/text()')[0]
              ip_port_str = '{}:{}'.format(ip, port)
              # 增量爬取
              if self.saver and self.saver.is_exist(ip_port_str):
                  continue
  
              # 测试ip: port是否可用
              if self.test_ip(ip, port):
                  self.save_data(ip_port_str)
                  print(ip, port, 'success')
              else:
                  print(ip, port, 'Failed')
  
              time.sleep(.5)
  
      def test_ip(self, ip, port):
          '测试IP 和 端口号是否可用，可用返回True, 否则返回False'
          proxies = {
              'http': 'http://{}:{}'.format(ip, port),
              'https': 'https://{}:{}'.format(ip, port),
          }
          test_url = 'https://httpbin.org/get'
          try:
              res = requests.get(url=test_url, proxies=proxies, timeout=5)
              if res.status_code == 200:
                  return True
          except Exception as e:
              pass
          return False
  
      def save_data(self, item):
          print(item)
          if self.saver:
              self.saver.save_item(item)
  
      # 主函数
      def run(self):
          # 成URL，获取数据
          # for page in range(1, 4526):
          for page in range(1, 4):
              url = self.url_fmt.format(page)
              html = self.get_html(url)
              self.parse_html(html)
              time.sleep(2)
  
  if __name__ == '__main__':
      saver = None
      # from proxies_poll_csv_saver import ProxiesCsvSaver
      # saver = ProxiesCsvSaver('proxies.csv')
      spider = GetProxyIP()
      spider.run()
  
  ```

- **总结requests.get()参数**

  ```python
  【1】 url
  【2】 params : {}
  【3】 proxies: {}
  【4】 auth   : ()
  【5】 headers: {}
  【6】 timeout: n
  【7】 verify : True | False
  ```



### 13. 课后练习

- 爬取链家二手房信息

```python
网址: https://bj.lianjia.com/ershoufang/

1、抓取链家二手房房源信息（房源名称、总价）,把结果存入到MySQL数据库,CSV文件
  # 小区名 、总价 、单价
  # 提示(有坑): 正则表达式请以响应内容为主
2、实现链家二手房的增量爬虫,用MySQL方式实现
```









## DAY02笔记



### 1. selenium爬虫

- **selenium概述**
  
- **定义**
  
  ```python
  1、Web自动化测试工具，可运行在浏览器,根据指令操作浏览器
  ```
  
- 特点
  
    ```
    1、简单，无需去详细抓取分析网络数据包，使用真实浏览器
    2、需要等待页面元素加载，需要时间，效率低
    ```
  
- 用途
  
  1. 对Web系统进行功能性测试,版本迭代时避免重复劳动
      兼容性测试(测试web程序在不同操作系统及浏览器中是否运行正常)
      对web系统进行大数量测试
  2. 爬虫(可以爬取动态的网站)
  
- **安装**
```shell
  # Linux下
  sudo pip3 install selenium
  # Windows下
  python -m pip install selenium
```

- 说明
  

Selenium 只是工具，必须与第三方浏览器结合使用

### 2. Selenium的安装和测试

- selenium的组合方式
  
  1. selenium + chromedriver + Chrome
  
  2. selenium + geckodriver + Firefox
  
  

> 以上2种组合任选其一，都可以实现基于selenium的强大网络爬虫
> Chrome需要安装浏览器驱动器：chromedriver
> Firefox需要安装浏览器驱动器：geckodriver

> chromedriver版本要和浏览器大版本对应，否则会闪退

#### selenium + chromedriver + Chrome浏览器

* **安装chromedriver**

  1. 查看Chrome浏览器的版本，下载最近的一个版本的chromedriver
  
  2. 下载chromedriver
  
      下载对应版本chromedriver
  
     - 下载地址
  
     https://npm.taobao.org/mirrors/chromedriver/
  
     或
  
     http://chromedriver.storage.googleapis.com/index.html
  
     二选一
  
  3. 安装chromedriver

      - windows安装

  ```shell
  
  # 1、解压 chromedriver_win32.zip   文件
  # 2、把chromedriver.exe拷贝到python安装目录的Scripts目录下(添加到系统环境变量)
    # 查看python安装路径: where python
  # 3、验证测试
     cmd命令行: chromedriver
  
  ```

    -       Linux安装

  ```python
  #  1、下载后解压 chromedriver_linux64.zip 文件
  unzip chromedriver_linux64.zip
  # 2、拷贝解压后chromedriver 文件到 /usr/bin/ （添加环境变量）
  sudo cp chromedriver /usr/bin/
  # 3、更改权限
  sudo chmod 777 /usr/bin/chromedriver
  
  ```


  4. 验证测试

  打开交互模式(python或 ipython)

  ```python
  $ python3
  >>> from selenium import webdriver
  >>> browser = webdriver.Chrome()
  # 成功启动chrome 浏览器即成功
  ```


#### selenium + geckodriver + Firefox浏览器

* **安装geckodriver**

  1. 下载geckodriver

      下载对应版本geckodriver

     - 下载地址

     https://github.com/mozilla/geckodriver/releases

  2. 安装geckodriver

  ```shell
  # windows安装
  1、解压缩 geckodriver 文件 geckodriver-v0.29.1-win64.zip
  2、把geckodriver.exe拷贝到python安装目录的Scripts目录下(添加到系统环境变量)
     # 查看python安装路径: where python
  3、验证
     cmd命令行: geckodriver
    
    
  # Linux安装
  # 1、下载后解压geckodriver-v0.29.1-linux64.tar.gz
  tar -zxvf geckodriver-v0.29.1-linux64.tar.gz
  # 2、拷贝解压后的 geckodriver 文件到 /usr/bin/ （添加环境变量）
  sudo cp geckodriver /usr/bin/
  # 3、更改权限
  sudo chmod 777 /usr/bin/geckodriver
  ```

  3. 验证测试

  打开交互模式(python或 ipython)

  ```python
  $ python3
  >>> from selenium import webdriver
  >>> browser = webdriver.Firefox()
  # 成功启动 Firefox 浏览器即成功
  ```



### 3. Selenium爬虫的使用

* **示例代码**

  ```python
  from selenium import webdriver
  
  # 创建浏览器对象
  browser = webdriver.Chrome()
  browser.get('https://www.baidu.com/')
  
  ```
  
```python
"""示例代码二：打开百度，搜索赵丽颖，点击搜索，查看"""

from selenium import webdriver
import time

# 1.创建浏览器对象 - 已经打开了浏览器
browser = webdriver.Chrome()

# 2.输入: http://www.baidu.com/
browser.get('http://www.baidu.com/')

# 3.找到搜索框,向这个节点发送文字: 赵丽颖
browser.find_element_by_xpath('//*[@id="kw"]').send_keys('赵丽颖')

# 4.找到 百度一下 按钮,点击一下
browser.find_element_by_xpath('//*[@id="su"]').click()

html = browser.page_source
with open('debug.html', 'w') as fw:
    fw.write(html)


# 关闭浏览器
time.sleep(10)
browser.quit()
```

* **浏览器对象(browser)方法**

  ```python
  1、browser = webdriver.Chrome(executable_path='path')
  2、browser.get(url)
  3、browser.page_source # HTML结构源码(动态生成后的DOM树对应的源码)
  4、browser.close() # 关闭当前页
  5、browser.quit() # 关闭浏览器
  ```
  
* **定位节点**

  ```python
  # 1、单元素查找(返回值为1个 WebElement 节点对象)
  1、browser.find_element_by_id('id属性值')
  2、browser.find_element_by_name('name属性值')
  3、browser.find_element_by_class_name('class属性值')
  4、browser.find_element_by_xpath('xpath表达式')
  5、browser.find_element_by_link_text('链接文本')
  6、browser.find_element_by_partical_link_text('部分链接文本')
  7、browser.find_element_by_tag_name('标记名称')
  8、browser.find_element_by_css_selector('css表达式')
  
  ... ...
  
  # 2、多元素查找(返回[WebElement节点对象列表])
  1、browser.find_elements_by_id('id属性值')
  2、browser.find_elements_by_name('name属性值')
  3、browser.find_elements_by_class_name('class属性值')
  4、browser.find_elements_by_xpath('xpath表达式')
  5、browser.find_elements_by_link_text('链接文本')
  6、browser.find_elements_by_partical_link_text('部分链接文本')
  7、browser.find_elements_by_tag_name('标记名称')
  8、browser.find_elements_by_css_selector('css表达式')
  ... ...
  ```
  
* **节点对象 WebElement 操作**

  在Selenium中，返回的节点对象 WebElement可以使用如下方法进行相应的操作

  ```python
  1、ele.send_keys('') # 向输入框写入数据，如: 搜索框发送内容
  2、ele.click()  # 向按钮或a标签发送“点击”事件
  3、ele.text # 获取文本内容，包含子节点和后代节点的文本内容
  4、ele.get_attribute('src') # 获取属性值
  ```

### 4. 豆瓣电影Top250 Selenium+Chrome爬虫示例

- 要求

  ```
  爬取豆瓣电影Top250的案例
  使用Selenium进行爬取
  目标: 电影名、评分、评分人数
  ```

- 示例

  ```python
  # file: douban_top250_selenium_spider.py
  '''
  爬取豆瓣电影Top250的案例
  使用Selenium进行爬取
  目标: 电影名、评分、评分人数
  '''
  import time
  
  from selenium import webdriver
  
  class DoubanTop250SeleniumSpider:
      def __init__(self, saver=None):
          self.saver = saver
          self.url = 'https://movie.douban.com/top250'
          self.browser = webdriver.Chrome()
  
      def parse_html(self):
          '''获取当前页面的数据.并解析'''
          li_list = self.browser.find_elements_by_xpath('//ol[@class="grid_view"]/li')
          # print(li_list)
          for li in li_list:
              ele = li.find_element_by_xpath('.//span[@class="title"]')
              # 目标: 电影名、评分、评分人数
              title = ele.text  # 电影名
              rating = li.find_element_by_xpath('.//span[@property="v:average"]').text  # 主演
              rating_count = li.find_element_by_xpath('.//div[@class="star"]/span[last()]').text.strip('人评价')  # 上映时间
              item = (title, rating, rating_count)
              self.save_data(item)
  
      def save_data(self, item):
          print(item)
          if self.saver:
              self.saver.save_item(item)
  
      def run(self):
          self.browser.get(self.url)
          time.sleep(5)
          # 循环爬取页面数据
          while True:
              self.parse_html()  # 解析当前页面
  
              try:
                  # 跳转到下一页，再继续解析
                  next_btn = self.browser.find_element_by_link_text('后页>')
                  next_btn.click()
                  time.sleep(5)
              except:
                  print('恭喜你!抓取结束')
                  break  # 正常结束
          self.browser.quit()
  
  
  if __name__ == '__main__':
      spider = DoubanTop250SeleniumSpider()
      spider.run()
  ```

## Selenium爬虫技能提高(附送，不讲)

### 1. selenium - 执行Javascript脚本程序

在使用selenium操作网页时，可以在页面内执行Javascript脚本程序来操作界面，进而实现更加复杂的功能。

- **执行Javascript脚本的方法**

```python
browser.execute_script('javascript脚本程序')
```

示例

```python
# 此示例可以将页面的滚动条拉带做低端
from selenium import webdriver
browser = webdriver.Chrome()
browser.execute_script(
    'window.scrollTo(0,document.body.scrollHeight)'
)
```

### 2. selenium的API操作

#### selenium - 键盘操作

使用 **WebElement** 的send_keys 方法可以向对应的元素输入按键操作

示例

```python
from selenium import webdriver
from selenium.webdriver.common.keys import Keys

browser = webdriver.Chrome()
browser.get('http://www.baidu.com/')
# 1、在搜索框中输入"selenium"
browser.find_element_by_id('kw').send_keys('赵丽颖')
# 2、输入空格
browser.find_element_by_id('kw').send_keys(Keys.SPACE)
# 3、Ctrl+a 模拟全选
browser.find_element_by_id('kw').send_keys(Keys.CONTROL, 'a')
# 4、Ctrl+c 模拟复制
browser.find_element_by_id('kw').send_keys(Keys.CONTROL, 'c')
# 5、Ctrl+v 模拟粘贴
browser.find_element_by_id('kw').send_keys(Keys.CONTROL, 'v')
# 6、输入回车,代替 搜索 按钮
browser.find_element_by_id('kw').send_keys(Keys.ENTER)
```



#### selenium - 鼠标操作

使用方法

```python
# 1. 用Selenium启动浏览器,并打开网页
from selenium import webdriver
browser = webdriver.Chrome()
browser.get(...)
# 2. 导入鼠标事件类
from selenium.webdriver import ActionChains
# 3. 鼠标移向的页面元素
e = browser.find_element_by_xpath('xpath路径')
# 4. 创建ActionChains对象，并向其发送鼠标移动事件并执行
ac = ActionChains(browser)   # 创建ActionChains对象
event = ac.move_to_element(e)  # 向e发送鼠标移动事件
event.perform()  # 执行
```



示例

```python
from selenium import webdriver
# 导入鼠标事件类
from selenium.webdriver import ActionChains

browser = webdriver.Chrome()
browser.get('http://www.baidu.com/')

#移动到 设置，perform()是真正执行操作，必须有
element = browser.find_element_by_xpath('//*[@id="s-usersetting-top"]')
ActionChains(browser).move_to_element(element).perform()

#单击，弹出的Ajax元素，根据链接节点的文本内容查找
browser.find_element_by_link_text('高级搜索').click()
```

#### selenium - 切换页面

在使用selenium打开页面时，一个网站可能会弹出多个页面，当要获取另外一个或多个页面时，可以使用Selenium的页面切换功能

- **适用网站**

```python
页面中点开链接出现新的页面，但是浏览器对象browser还是之前页面的对象
```

- **操作方法**

```python
# 获取当前所有句柄（窗口）- [handle1,handle2]
all_handles = browser.window_handles
# 切换browser到新的窗口，获取新窗口的对象
browser.switch_to.window(all_handles[1])
```





### 3. 课后练习

#### 百度壁纸爬取 -  练习

- 目标

  爬取百度图片中 "养眼壁纸" 中的 "高清" 壁纸 20张

- 要求

  使用 Selenium进行爬取

- 代码

```python
'''
使用 Selenium爬取 百度图片中的超清大图
'''

from selenium import webdriver
import time
import os
import requests

class BaiduImageSpider:
    def __init__(self, keyword):
        self.keywords = keyword
        self.save_to = './' + keyword
        try:
            os.makedirs(self.save_to)  # 创建文件夹
        except Exception as err:
            print(self.save_to, ':', err)

        self.url = 'https://image.baidu.com/'
        self.browser = webdriver.Chrome()
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.116 Safari/537.36'
        }

    def download_image(self, url, number):
        print(number, ":", url)
        filename = str(number) + '.jpg'
        pathname = os.path.join(self.save_to, filename)
        resp = requests.get(url, headers=self.headers)
        with open(pathname, 'wb') as fw:
            fw.write(resp.content)

    def enter_image_page(self):
        self.browser.maximize_window()
        # 进入百度图片首页
        self.browser.get(self.url)
        element = self.browser.find_element_by_xpath('//*[@id="kw"]')
        element.send_keys(self.keywords)  # 输入关键字
        element = self.browser.find_element_by_xpath('//*[@id="homeSearchForm"]/span[2]/input')
        element.click()  # 进行搜索
        element = self.browser.find_element_by_xpath('//*[@id="typeFilter"]/div[2]/ul/li[2]')
        element.click()  # 点击'高清'
        # 进入预览界面
        time.sleep(2)
        element = self.browser.find_element_by_xpath('//*[@id="imgid"]/div/ul/li[1]/div/div/a')
        element.click()
        # 切换窗口到
        all_handle = self.browser.window_handles
        self.browser.switch_to.window(all_handle[1])

    def parse_link_and_download(self):
        for i in range(20):
            element = self.browser.find_element_by_xpath('//*[@id="currentImg"]')
            url = element.get_attribute('src')
            self.download_image(url, i+1)
            try:
                next_page_element = self.browser.find_element_by_xpath('//*[@id="container"]/span[2]')
                next_page_element.click()
            except:
                print('爬取完毕')
                break

    def run(self):
        self.enter_image_page()
        self.parse_link_and_download()


if __name__ == '__main__':
    spider = BaiduImageSpider('养眼壁纸')
    spider.run()
```






